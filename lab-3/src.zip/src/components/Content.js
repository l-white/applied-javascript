import React from "react";


const Content = ({firstName}) => {
  return (
  <div className="container">
    <h1>Basic Navbar Example</h1>
    <p>A navigation bar is a navigation header that is placed at the top of the page.</p>
  </div>
  );
}

export default Content;