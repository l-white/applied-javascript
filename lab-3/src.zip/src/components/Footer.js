const Footer = () => {
  return (
    `Copyright ${new Date().getFullYear()}`
  );
}

export default Footer;