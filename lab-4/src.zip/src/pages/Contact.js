import React from "react";

const Contact = () => {
  return (
    <>
    <h1>Contact</h1>
    <p>Contact form to come, once we cover the topic of state in React!</p>
    </>
  );
}

export default Contact;