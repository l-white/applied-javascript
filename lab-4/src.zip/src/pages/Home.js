import React from "react";

const Home = () => {
  return (
    <>
      <h1>Home</h1>
      <p>A navigation bar is a navigation header that is placed at the top of the page.</p>
    </>
  );
}

export default Home;