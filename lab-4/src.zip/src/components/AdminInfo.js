import React from 'react';

function AdminInfo(props){
  return(
      <div>{props.author}</div>
  );
}

export default AdminInfo;